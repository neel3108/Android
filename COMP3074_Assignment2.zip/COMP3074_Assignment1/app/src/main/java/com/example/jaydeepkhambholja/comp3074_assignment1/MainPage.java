package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainPage extends AppCompatActivity implements View.OnClickListener {


    @Override
    public void onClick(View v) {
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        Log.d("TEST","onCreate_EventList");
        findViewById(R.id.btnBack).setOnClickListener(this);
        SharedPreferences prefs = getSharedPreferences("MyApp", MODE_PRIVATE);
        String username = prefs.getString("username", "");
        TextView welcome = (TextView)findViewById(R.id.txtWelcome);
        welcome.setText("Welcome "+username+"!");

        //when button General Schedule is press
        findViewById(R.id.btnGenSch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), GeneralSchedule.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button My Schedule is press
        findViewById(R.id.btnMySch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), MySchedule.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button Speaker is press
        findViewById(R.id.btnSpeakers).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), Speakers.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button Mao with interest places is press
        findViewById(R.id.btnMap).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), MapPlaces.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button Attendees is press
        findViewById(R.id.btnAttendees).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), ListOfAttendees.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button Sponsors is press
        findViewById(R.id.btnSponsors).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), Sponsors.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button Twitter is press
        findViewById(R.id.btnTwitter).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), Twitter.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });

        //when button survey is press
        findViewById(R.id.btnSurvey).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), Survey.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });
    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d("TEST","onStart_EventList");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("TEST","onResume_EventList");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d("TEST","onPause_EventList");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("TEST","onStop_EventList");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("TEST","onDestroy_EventList");
    }

}
