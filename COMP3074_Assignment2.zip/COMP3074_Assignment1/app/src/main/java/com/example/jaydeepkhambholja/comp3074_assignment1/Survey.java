package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Survey extends AppCompatActivity {

    EditText q1Answer, q2Answer, q3Answer;
    String q1Ans,q2Ans,q3Ans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        //when button  is press
        findViewById(R.id.btnServeySubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q1Answer = (EditText) findViewById(R.id.txtBx1);q2Answer = (EditText) findViewById(R.id.txtBx2);q3Answer = (EditText) findViewById(R.id.txtBx3);
                q1Ans = q1Answer.getText().toString();q2Ans = q2Answer.getText().toString();q3Ans = q3Answer.getText().toString();
                if(!q1Ans.isEmpty()&& (!q2Ans.isEmpty()&& !q3Ans.isEmpty())) {
                    if (!save(dataToSave(q1Ans, q2Ans, q3Ans))) {
                        Toast.makeText(getApplicationContext(), "Unexpected Error encountered.", Toast.LENGTH_LONG).show();
                    }else{
                        q1Answer.getText().clear();
                        q2Answer.getText().clear();
                        q3Answer.getText().clear();
                        Toast.makeText(getApplicationContext(), "Done. Submitted", Toast.LENGTH_LONG).show();
                    }
                }else {
                    if(q1Ans.isEmpty()){
                        q1Answer.setError("Please input value!");
                    }
                    if(q2Ans.isEmpty()){
                        q2Answer.setError("Please input value!");
                    }
                    if(q3Ans.isEmpty()){
                        q3Answer.setError("Please input value!");
                    }
                }

            }
        });

        findViewById(R.id.btnResult).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Regular start of the activity
                Intent i = new Intent(v.getContext(), ServeyResult.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
            }
        });
    }



    public String dataToSave(String q1Answer,String q2Answer,String q3Answer ){
        return timestamp()+"\t"+ q1Answer+";"+ q2Answer+";"+ q3Answer+";\n";
    }
    public boolean save(String str) {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput("survey.txt", MODE_APPEND);
            fos.write(str.getBytes());
            return true;
            //Toast.makeText(this, "Result Saved!",Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public String timestamp(){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.CANADA);
        Date date = new Date();
        return formatter.format(date);
    }

}
