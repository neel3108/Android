package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import com.example.jaydeepkhambholja.comp3074_assignment1.PresenterInfo;

public class DBHandler extends SQLiteOpenHelper {

    //information of database
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "presenterDB.db";
    private static final String TABLE_NAME = "Presenter";
    private static final String COLUMN_ID = "PresenterID";
    private static final String COLUMN_NAME = "FirstName";
    private static final String COLUMN_LNAME = "LastName";
    private static final String COLUMN_AFFILIATION = "Affiliation";
    private static final String COLUMN_EMAIL = "Email";
    private static final String COLUMN_SHORTBIO = "Short_Bio";

    //initialize the database
    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        try {
            String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_LNAME + " TEXT,"
                    + COLUMN_AFFILIATION + " TEXT,"
                    + COLUMN_EMAIL + " TEXT,"
                    + COLUMN_SHORTBIO + " TEXT"
                    + ")";
            db.execSQL(CREATE_TABLE);
        }catch (Exception e){
            Log.d("Error", e.getMessage().toString());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Create tables again
        onCreate(db);
    }

    public void addHandler(PresenterInfo presenter){

        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, presenter.getFname());
        values.put(COLUMN_LNAME, presenter.getLname());
        values.put(COLUMN_AFFILIATION, presenter.getAffliation());
        values.put(COLUMN_EMAIL, presenter.getEmail());
        values.put(COLUMN_SHORTBIO, presenter.getShortBio());
        db.insert(TABLE_NAME, null, values);
        db.close();

    }

    public String loadHandler(){

        String result = "";
        String query = "SELECT * FROM " + TABLE_NAME;
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){

            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            String result_2 = cursor.getString(2);
            String result_3 = cursor.getString(3);
            String result_4 = cursor.getString(4);
            String result_5 = cursor.getString(5);

            result += String.valueOf(result_0)+", "+result_1+", "
                    +result_2+", "+result_3+", "+result_4+", "+result_5 +System.getProperty("line.separator");
        }

        cursor.close();
        db.close();
        return result;

    }

    public String listViewHandler(){

        String result = "";
        String query = "SELECT "+COLUMN_NAME+" ,  "+COLUMN_LNAME +" FROM " + TABLE_NAME;
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){

            String result_1 = cursor.getString(0);
            String result_2 = cursor.getString(1);

            result += result_1+", "+result_2+ "///";
        }

        cursor.close();
        db.close();
        return result;

    }

    public PresenterInfo findHandler(String fName, String lName){


        String query = "SELECT * FROM "+ TABLE_NAME+ "  WHERE " + COLUMN_NAME + " = '"+fName+"' "
                + "AND " + COLUMN_LNAME + " = '"+lName+"' ;";
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        PresenterInfo presenter = new PresenterInfo();
        if (cursor.moveToNext()) {
            cursor.moveToFirst();
            presenter.setID(cursor.getInt(0));
            presenter.setFname(cursor.getString(1));
            presenter.setLname(cursor.getString(2));
            presenter.setAffliation(cursor.getString(3));
            presenter.setEmail(cursor.getString(4));
            presenter.setShortBio(cursor.getString(5));
            cursor.close();
        } else {
            presenter = null;
        }
        db.close();
        return presenter;

    }
}
