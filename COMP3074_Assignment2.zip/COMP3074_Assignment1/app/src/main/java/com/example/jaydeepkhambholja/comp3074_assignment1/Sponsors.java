package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Sponsors extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsors);
    }
}
