package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Speakers extends AppCompatActivity {



    DBHandler db;
    Context context;
    TextView a;
    ListView listView;
    ArrayList<String> arrayList;
    ArrayAdapter arrayAdapter;
    String[] data;
    PresenterInfo p;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speakers);


        db = new DBHandler(this);
        String splitData = db.listViewHandler();

        if(!splitData.isEmpty()) {

            data = splitData.split("///");
            listView = (ListView) findViewById(R.id.listSpeak);

            arrayList = new ArrayList<>();

            for (int i = 0; i < data.length; i++) {
                arrayList.add(data[i]);
            }

            arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, arrayList);

            listView.setAdapter(arrayAdapter);


            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String data = arrayList.get(position);
                    String[] splitData = data.split(", ");
                    Log.d("DATA", splitData[0]);
                    Log.d("DATA2", splitData[1]);
                    p = db.findHandler(splitData[0], splitData[1]);
                    if (p != null) {
                        Log.d("First Name from DB", p.getFname());
                        Log.d("Last Name from DB", p.getLname());
                        Intent intent = new Intent(view.getContext(), ListViewResult.class);
                        intent.putExtra("Fname", p.getFname());
                        intent.putExtra("Lname", p.getLname());
                        intent.putExtra("email", p.getEmail());
                        intent.putExtra("afflication", p.getAffliation());
                        intent.putExtra("bio", p.getShortBio());
                        startActivity(intent);
                    } else {
                        Log.d("DB Error:", "The data was not fetched from the database.");
                    }
                }
            });
        }

        //when button My Schedule is press
        findViewById(R.id.btnAddPre).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                Intent i = new Intent(v.getContext(), Registration.class);
                startActivity(i);
                overridePendingTransition(R.anim.slide_left,R.anim.slide_left);
                finish();
            }
        });


    }
}