package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registration extends AppCompatActivity {


    DBHandler db;
    PresenterInfo p;
    String sFname, sLname, sAffiliation, sEmail, sBio;
    EditText fname, lname, afflication, email, bio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        db = new DBHandler(this);

        findViewById(R.id.btnRegister).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Regular start of the activity
                fname = findViewById(R.id.txtBxFname);
                sFname = fname.getText().toString();
                if (sFname.isEmpty()){
                    fname.setError("First Name required!");
                }
                lname = findViewById(R.id.txtBxLname);
                sLname = lname.getText().toString();
                if (sLname.isEmpty()){
                    lname.setError("Last Name required!");
                }
                afflication = findViewById(R.id.txtBxRole);
                sAffiliation = afflication.getText().toString();
                if (sAffiliation.isEmpty()){
                    afflication.setError("Affiliation Name required!");
                }
                email = findViewById(R.id.txtBxEmail);
                sEmail = email.getText().toString();
                if (sEmail.isEmpty()){
                    email.setError(" Email required!");
                }
                if (!isEmail(sEmail)){
                    email.setError(" Not a valid email!");
                }
                bio = findViewById(R.id.txtBxShortBio);
                sBio = bio.getText().toString();
                if (sBio.isEmpty()){
                    bio.setError("Short Bio required!");
                }
                if (!sFname.isEmpty() && !sLname.isEmpty() && !sEmail.isEmpty() && !sAffiliation.isEmpty() && !sBio.isEmpty() && isEmail(sEmail)) {
                    p = new PresenterInfo(sFname, sLname, sAffiliation, sEmail, sBio);
                    db.addHandler(p);
                    fname.getText().clear();
                    lname.getText().clear();
                    afflication.getText().clear();
                    email.getText().clear();
                    bio.getText().clear();
                    Toast.makeText(getApplicationContext(), "Presenter successfully added.", Toast.LENGTH_LONG).show();
                }
                else {
                    Log.d("Error", "Something wrong");
                }
            }
        });
    }

    public static boolean isEmail(String str) {
        Pattern p = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
        Matcher m = p.matcher(str);
        return (m.find()&&m.group().equals(str));
    }
}