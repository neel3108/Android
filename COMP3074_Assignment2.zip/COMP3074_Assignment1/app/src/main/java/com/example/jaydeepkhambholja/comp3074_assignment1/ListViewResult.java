package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ListViewResult extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_result);

        Intent intent = getIntent();
        String Fname = intent.getStringExtra("Fname");
        String Lname = intent.getStringExtra("Lname");
        String afflication = intent.getStringExtra("afflication");
        String email = intent.getStringExtra("email");
        String bio = intent.getStringExtra("bio");
        String data = "First Name: "+ Fname+"\n"
                +"Last Name: "+ Lname +"\n"
                +"Affiliation: "+ afflication+"\n"
                +"Email: "+ email +"\n"
                + "Short Bio: "+ bio +"\n";

        textView = findViewById(R.id.txtPreResults);
        textView.setText(data);
    }
}
