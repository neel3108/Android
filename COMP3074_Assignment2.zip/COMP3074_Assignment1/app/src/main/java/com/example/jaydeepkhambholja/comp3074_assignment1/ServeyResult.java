package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class ServeyResult extends AppCompatActivity {

    private static final String FILE_NAME = "survey.txt";
    TextView a;
    View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servey_result);
        a = (TextView) findViewById(R.id.txtViewResult);
        load();
    }

    public void load() {
        FileInputStream fis = null;

        try {
            fis = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            int i = 1;
            while ((text = br.readLine()) != null) {
                sb.append("Response Number: ").append(i).append("\n");
                sb.append(splitData(text));
                sb.append("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*\n");
                i++;
            }
            a.setText(sb.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public String splitData(String text){
        StringBuilder data = new StringBuilder();
        String[] splitData;
        splitData = text.split("\t",0);
        splitData = splitData[1].split(";");
        for (String packet: splitData) {
            data.append("Answer: ").append(packet).append("\n");
        }

        return data.toString();
    }

//    public void deleteFile(){
//        File file = new File(getFilesDir(),FILE_NAME);
//        if(file.exists()){
//            deleteFile(FILE_NAME);
//            Toast.makeText(this, "Deleted!",Toast.LENGTH_LONG).show();
//        }else{
//            Toast.makeText(this, "File not found!",Toast.LENGTH_LONG).show();
//        }
//    }
}