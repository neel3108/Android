package com.example.jaydeepkhambholja.comp3074_assignment1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText name;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("TEST","onCreate-Main");

        findViewById(R.id.btnLogIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = (EditText) findViewById(R.id.editTxUser);

                if (TextUtils.isEmpty(name.getText())) {


                    name.setError("First name is required!");

                } else {
                    String name1 = name.getText().toString();
                    SharedPreferences prefs = getSharedPreferences("MyApp", MODE_PRIVATE);
                    prefs.edit().putString("username", name1).commit();
                    //Regular start of the activity
                    Intent i = new Intent(v.getContext(), MainPage.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.slide_left, R.anim.slide_left);
                }
            }
        });


    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d("TEST","onStart");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d("TEST","onResume");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d("TEST","onPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d("TEST","onStop");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d("TEST","onDestroy");
    }
}
