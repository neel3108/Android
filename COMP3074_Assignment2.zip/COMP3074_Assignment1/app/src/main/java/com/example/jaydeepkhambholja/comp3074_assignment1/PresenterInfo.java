package com.example.jaydeepkhambholja.comp3074_assignment1;


import java.io.Serializable;

public final class PresenterInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private  int ID;
    private String fName, lName, affliation, email , shortBio = "";

    public PresenterInfo(){

    }

    public PresenterInfo(String fname, String lname, String affliation, String email, String shortBio){

        this.fName = fname;
        this.lName = lname;
        this.affliation = affliation;
        this.email = email;
        this.shortBio = shortBio;

    }

    //Setters

    public void setFname(String fName){
        this.fName = fName;
    }

    public void setLname(String lName){
        this.lName = lName;
    }

    public void setAffliation(String affliation){
        this.affliation = affliation;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public void setShortBio(String shortBio){
        this.shortBio = shortBio;
    }

    public void setID(int ID){ this.ID = ID; }

    //Getters

    public String getFname(){
        return this.fName;
    }

    public String getLname(){
        return this.lName;
    }

    public String getAffliation(){ return this.affliation; }

    public String getEmail(){
        return this.email;
    }

    public String getShortBio(){ return this.shortBio; }

    public int getID(){
        return this.ID;
    }
}