package com.example.neelp.comp3074_a1;

import android.os.Bundle;
import android.app.Activity;

public class ScrollingActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
    }
}
